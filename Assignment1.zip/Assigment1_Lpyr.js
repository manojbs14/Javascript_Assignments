let year = 1986
let LP1 = new LP(year);

function LP(year){
isleapyear = year % 4
return isleapyear
}

if (isleapyear==0)
 console.log("Leap year")
else
console.log("not a leap year")