let Factnum = 6;
let findfact = fact(Factnum);


function fact(Factnum)
{
    let Factnum1 = 1,i;
    for(i=1;i<=Factnum;i++)
    {
        Factnum1 = Factnum1*i;                
    }
    console.log(Factnum1);  
    
}