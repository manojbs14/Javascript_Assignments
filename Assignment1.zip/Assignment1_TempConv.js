let F , C, X;
C = 140;
F = 120;
X = F;
let tempcon = new Tempcon();

function Tempcon(){

    switch(X){
        case F:
            F = (C * 9/5) + 32
            console.log("Farenhit is",F);
            break;

        case C:
            C = (F - 32) * 5/9
            console.log("Celsius is ",C);
            break;

        default:            

    }
        
}
