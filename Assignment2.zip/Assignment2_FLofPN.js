let Factnumlow = 1
let factnumhigh = 100

let findfactPN = new factPN(Factnumlow,Factnumlow);


function factPN(Factnumlow,Factnumlow)
{
    
    for (i=Factnumlow;i<=factnumhigh;i++){
        if(i%2==0){                            
            }
            else{
                let Factnum1=1;
                for(j=1;j<=i;j++)
                {
                    Factnum1 = Factnum1*j;                
                }
                console.log("Factorial number of",i,"is",Factnum1);  
            }
            
        } 
    }    
