let studentmark = 35;
let a;
let gradeval = new findgrade();

function findgrade(){
    if (studentmark <= 100 && studentmark >= 90)
    {
        a=1;
    }
    else if (studentmark <= 90 && studentmark >= 80)
    {
        a=2;
    }
    else if (studentmark <= 80 && studentmark >= 70)
    {
        a=3;
    }
    else if (studentmark <= 70 && studentmark >= 60)
    {
        a=4;
    }
    else if (studentmark <= 60 && studentmark >= 50)
    {
        a=5;
    }
    else if (studentmark <= 50 && studentmark >= 40)
    {
        a=6;
    }
    else if (studentmark <40 && studentmark >0)
    {
        a=7;
    }
    

    switch(a)
    {     

        case 1:
            console.log("S Grade")
            break;
        
        case 2:
            console.log("A Grade")
            break;

        case 3:
            console.log("B Grade")
            break;

        case 4:
            console.log("C Grade")
            break;
            
        case 5:
            console.log("D Grade")
            break;
        
        case 6:
            console.log("E Grade")
            break; 
        
        case 7:
            console.log("Student Fail")
            break; 
        
        default:
            console.log("Invalid Marks");

    }

}

