let a , b ,c;
a=11;
b=11;
c=3;
let fn = new identifytriangle(a,b,c)

function identifytriangle(a,b,c){

    if(a==b && a==c && b==c)
    {
        console.log("Triangle is Equilateral")
    }
    else if (a!=b && a!=c && b!=c)
    {
        console.log("Triangle is Scalene")
    }
    else if (a == b || a == c || b == c)
    {
        console.log("Triangle is Isosceles")

    }
     
}