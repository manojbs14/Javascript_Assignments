let mulnum = 1000;
let SOM1 = new som()

function som(){
    let i,sum=0;
    if (mulnum<1000){ 
        for(i=0;i<=mulnum;i++)
        {
            if(i % 3 ==0 || i % 5 == 0)
            {
                sum += i
                }
        }
       console.log(sum)
        
    }
    else
        console.log("number is greater than 1000")
}