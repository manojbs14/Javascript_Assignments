let add = 0
const number = 143;
const digits = String(number).split('').map(Number);  
console.log(digits);
let len = digits.length
console.log(len)

for(i=0;i<len;i++){
    let a ,k
    a = digits[i]
    k = a*a*a
    add = add + k
    //console.log(add)
}
//console.log(add)

if (add == number){
  console.log(add,":Number is armstrong")
}
else
  console.log(add,":Number is not an armstrong number")

