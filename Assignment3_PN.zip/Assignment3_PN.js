let int = "";
let count = 0

for (i=1;i<=4;i++){

    
    for(j=1;j<=i;j++){
        count=count+1              
        int += count;   
    }
    int += "\n"
}console.log(int);
