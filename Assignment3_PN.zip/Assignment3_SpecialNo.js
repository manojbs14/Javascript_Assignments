let add = 0
const number = 153;
const digits = String(number).split('').map(Number); 
let len = digits.length

  for(i=0;i<len;i++)
    {
      
      let Factnum1=1;  
      for(j=1;j<=digits[i];j++){
          Factnum1 = Factnum1*j; 
          
          
        }  add = add + Factnum1
        console.log(add)
    }            
  
    if (add == number)
    {
      console.log("number is a special number")
    }
    else
      console.log("number is not a special number")