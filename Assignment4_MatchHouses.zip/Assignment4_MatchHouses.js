

function MatchHouses(matchhouse){
    let result = 0;

for(i=1;i<=matchhouse;i++){

    if(i==1){
        result = result + 6;
    }
    if(i>1){
        result = result + 5;
    }

    
}
return result;

}

let userInput = 4
let result = MatchHouses(userInput)
console.log(result);