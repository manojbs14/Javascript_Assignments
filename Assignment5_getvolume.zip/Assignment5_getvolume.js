class getVolume{

    constructor(radius , height , Shape){

    this.radius = radius;
    this.height = height;
    this.Shape = Shape;

    }

    getvolume(){

        let result;
        let pi = 3.14;
        switch(this.Shape){
            case 'Cylinder':
                result = pi * ((this.radius)**2) * this.height;
                break;
            
            case 'Sphere':
                result = ((4/3) * pi * ((this.radius)**3));
                break;

            case 'Cone':
                result = pi * ((this.radius)**2) * (this.height/3);
                break;

        }
        return result;
    }
}

let Vol = new getVolume(3,3,"Cone")
let result = Vol.getvolume();
console.log(result.toFixed(4))