function Dashes(nums){

    const digits = String(nums).split('').map(Number); 
    let len = digits.length
    
    let Acc =0;
    let prevno =0, evenflag ,vale;

    for (let i=0;i<len;i++)
    {       
        if(digits[i]%2==0)
        {
            if(prevno==0 || prevno%2==0) 
            {          
            console.log("ival",digits[i])
            vale=digits[i]
            Acc = Acc + "-" +digits[i]
            }
            //console.log("1",Acc);
            else{
            Acc = Acc + "" +digits[i]
            vale=digits[i]                   
            }
        }
        else{
            Acc = Acc+digits[i]
            vale=digits[i]           
            evenflag=false
            //console.log(Acc)
        }   
        prevno=vale
    }
    return Acc
}

let nums = 123445
let Acc = Dashes(nums)

console.log(Acc);


