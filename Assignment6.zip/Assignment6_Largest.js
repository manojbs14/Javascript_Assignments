function Largest(){

    for(i=1;i<=2;i++)
    {
        let LN = Math.max.apply(null,nums);
    let ind = nums.indexOf(LN)
    nums.splice(ind)
    }
let LNA = Math.max.apply(null,nums);
return LNA
}

let nums = [1,2,3,4,5]
let LNA = Largest();
console.log(LNA);