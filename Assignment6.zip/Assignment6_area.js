class Rect{
    constructor(width , height){
        this.width = width;
        this.height = height;
    }

    area(){
        let Result = this.width * this.height
        return Result
    }
    
}

class square extends Rect{
    constructor(s1,s2){
        super (s1,s2)
    }
}

let sq = new square(3,3)
let Result = sq.area()
console.log(Result);